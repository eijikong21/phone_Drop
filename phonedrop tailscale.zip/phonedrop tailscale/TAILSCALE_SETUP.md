# PhoneDrop — Tailscale Setup

## 1. Install Tailscale

- PC:     https://tailscale.com/download  (Windows installer)
- iPhone: App Store → search "Tailscale"

Sign in with the SAME account on both devices (Google or GitHub works).

---

## 2. Get your PC's Tailscale IP

After installing, click the Tailscale icon in your system tray.
Your IP will look like: 100.x.x.x  — note it down.

---

## 3. Run PhoneDrop

In your PhoneDrop folder:

  node index.js

The console will now show:

  | Tailscale (works anywhere):                |
  |   http://100.x.x.x:49372                  |

---

## 4. Connect from iPhone

Open Safari on your iPhone and go to:

  http://100.x.x.x:49372

Replace 100.x.x.x with your actual Tailscale IP.
This works from anywhere — home WiFi, mobile data, coffee shop, etc.

---

## 5. Auto-start on Windows boot (optional)

So PhoneDrop is always running without you having to launch it manually:

1. Press  Win + R
2. Type   shell:startup   and hit Enter
3. Copy   phonedrop.bat   into that folder
4. Done — PhoneDrop starts automatically every time Windows boots

---

## Notes

- Tailscale must be running on BOTH devices for the connection to work
- Your PC must be on and PhoneDrop must be running
- The Tailscale IP (100.x.x.x) never changes — bookmark it on your phone
- On home WiFi, traffic stays local (Tailscale is smart about this)
- On mobile data or away from home, traffic goes through encrypted WireGuard tunnel
