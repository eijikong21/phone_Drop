@echo off
cd /d "%~dp0"

:: Check if node is accessible
where node >nul 2>&1
if %errorlevel% == 0 goto run

:: Try common Node.js install locations
if exist "%ProgramFiles%\nodejs\node.exe" (
  set NODE="%ProgramFiles%\nodejs\node.exe"
  goto run_explicit
)
if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
  set NODE="%ProgramFiles(x86)%\nodejs\node.exe"
  goto run_explicit
)
if exist "%APPDATA%\nvm\current\node.exe" (
  set NODE="%APPDATA%\nvm\current\node.exe"
  goto run_explicit
)

echo [!] Node.js not found. Install from https://nodejs.org
pause
exit /b 1

:run
start "PhoneDrop" cmd /k "node index.js"
goto end

:run_explicit
start "PhoneDrop" cmd /k "%NODE% index.js"

:end
