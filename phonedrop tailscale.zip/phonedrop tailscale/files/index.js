'use strict';

const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const os      = require('os');
const http    = require('http');
const QRCode  = require('qrcode');
const sharp   = require('sharp');

// ─── Config ────────────────────────────────────────────────────────────────
const BASE_PORT    = 49372;
const RECEIVED_DIR = path.join(__dirname, 'received');
if (!fs.existsSync(RECEIVED_DIR)) fs.mkdirSync(RECEIVED_DIR, { recursive: true });

// ── Compression quality (1–100). Change this or adjust via the UI slider. ──
// 92  = visually lossless, ~30-50% smaller than iPhone original  (default)
// 80  = great quality, noticeable size reduction
// 60  = smaller files, slight quality loss on close inspection
// PNG is always lossless — quality only affects JPEG and WebP.
let JPEG_QUALITY = 92;

// Formats sharp can optimize (keep same format, strip metadata, recompress)
const OPTIMIZABLE_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp']);
const IMAGE_EXTS       = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.heic', '.heif', '.avif']);

// ─── Network helpers ───────────────────────────────────────────────────────
function getTailscaleIP() {
  const ifaces = os.networkInterfaces();
  for (const [name, addrs] of Object.entries(ifaces)) {
    const n = name.toLowerCase();
    // Tailscale shows up as "Tailscale" on Windows or "tailscale0" on Linux/Mac
    if (!n.includes('tailscale') && !n.includes('ts')) continue;
    for (const addr of addrs) {
      if (addr.family !== 'IPv4' || addr.internal) continue;
      // Tailscale IPs are always in the 100.64.0.0/10 CGNAT range
      if (addr.address.startsWith('100.')) return addr.address;
    }
  }
  return null;
}

function getAllLocalIPs() {
  const ifaces = os.networkInterfaces();
  const results = [];
  for (const [name, addrs] of Object.entries(ifaces)) {
    const n = name.toLowerCase();
    if (n.includes('loopback') || n.includes('vmware') || n.includes('virtualbox') || n.includes('tunnel') || n.includes('tap')) continue;
    for (const addr of addrs) {
      if (addr.family !== 'IPv4' || addr.internal) continue;
      const priv = addr.address.startsWith('192.168.') || addr.address.startsWith('10.') || /^172\.(1[6-9]|2\d|3[01])\./.test(addr.address);
      if (priv) results.push({ ip: addr.address, iface: name });
    }
  }
  return results;
}

function isPortFree(port) {
  return new Promise(resolve => {
    const s = http.createServer();
    s.once('error', () => resolve(false));
    s.once('listening', () => { s.close(); resolve(true); });
    s.listen(port, '0.0.0.0');
  });
}

async function findFreePort(start, range = 20) {
  for (let p = start; p < start + range; p++) {
    if (await isPortFree(p)) return p;
  }
  return null;
}

// ─── File storage (multer writes to temp first) ────────────────────────────
function getTodayDir() {
  const d = new Date();
  const folder = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const dir = path.join(RECEIVED_DIR, folder);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function nextIndex(dir) {
  const nums = fs.readdirSync(dir).map(f => parseInt(f.split('_')[0], 10)).filter(n => !isNaN(n));
  return String(nums.length ? Math.max(...nums) + 1 : 1).padStart(3, '0');
}

// Write to a temp dir first; we optimize before moving to final location
const TEMP_DIR = path.join(__dirname, '.tmp');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, TEMP_DIR),
  filename: (_req, file, cb) => cb(null, `${Date.now()}_${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase() || '.bin'}`)
});

const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// ─── Image optimization ────────────────────────────────────────────────────
// Same format, no quality loss — strips metadata + applies best compression.
// JPEG: mozjpeg encoder at quality 92 (visually lossless, ~30-50% smaller)
// PNG:  max zlib compression level, lossless
// WebP: lossless recompress, strip metadata
async function optimizeImage(srcPath, ext) {
  const img = sharp(srcPath);
  const meta = await img.metadata();

  let pipeline = img;

  if (ext === '.jpg' || ext === '.jpeg') {
    pipeline = pipeline.jpeg({ quality: JPEG_QUALITY, mozjpeg: true });
  } else if (ext === '.png') {
    pipeline = pipeline.png({ compressionLevel: 9, effort: 10 });
  } else if (ext === '.webp') {
    if (meta.hasAlpha) {
      pipeline = pipeline.webp({ lossless: true, effort: 6 });
    } else {
      pipeline = pipeline.webp({ quality: JPEG_QUALITY, effort: 6 });
    }
  }

  // Always strip metadata (EXIF, GPS, ICC profiles etc.) — biggest size win
  pipeline = pipeline.withMetadata(false);

  const outPath = srcPath + '_opt' + ext;
  await pipeline.toFile(outPath);

  const srcSize = fs.statSync(srcPath).size;
  const outSize = fs.statSync(outPath).size;

  // Only keep the optimized version if it's actually smaller
  if (outSize < srcSize) {
    fs.unlinkSync(srcPath);
    return { path: outPath, savedBytes: srcSize - outSize };
  } else {
    fs.unlinkSync(outPath);
    return { path: srcPath, savedBytes: 0 };
  }
}

// ─── Process uploaded file: optimize if image, then move to received/ ─────
async function processFile(tmpPath, originalName) {
  const ext  = (path.extname(originalName) || '.bin').toLowerCase();
  const base = path.basename(originalName, path.extname(originalName)).replace(/[^a-z0-9._-]/gi, '_').substring(0, 40);
  const dir  = getTodayDir();
  const idx  = nextIndex(dir);
  const finalName = `${idx}_${base}${ext}`;
  const finalPath = path.join(dir, finalName);

  let savedBytes = 0;

  if (OPTIMIZABLE_EXTS.has(ext)) {
    try {
      const result = await optimizeImage(tmpPath, ext);
      fs.renameSync(result.path, finalPath);
      savedBytes = result.savedBytes;
    } catch (e) {
      // If optimization fails for any reason, just move the original
      fs.renameSync(tmpPath, finalPath);
    }
  } else {
    fs.renameSync(tmpPath, finalPath);
  }

  // Clean up temp if still exists
  if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);

  return { finalName, savedBytes };
}

// ─── Helpers ───────────────────────────────────────────────────────────────
function isImage(filename) {
  return IMAGE_EXTS.has(path.extname(filename).toLowerCase());
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ─── App ───────────────────────────────────────────────────────────────────
const app = express();

app.use('/received', express.static(RECEIVED_DIR));
app.use(express.json());

// Config: read current quality
app.get('/config', (_req, res) => {
  res.json({ quality: JPEG_QUALITY });
});

// Config: update quality at runtime (no restart needed)
app.post('/config', (req, res) => {
  const q = parseInt(req.body.quality, 10);
  if (isNaN(q) || q < 1 || q > 100) return res.status(400).json({ error: 'quality must be 1-100' });
  JPEG_QUALITY = q;
  console.log(`[~] Compression quality set to ${JPEG_QUALITY}%`);
  res.json({ ok: true, quality: JPEG_QUALITY });
});

// Upload + optimize
app.post('/upload', upload.array('files', 20), async (req, res) => {
  if (!req.files || req.files.length === 0) return res.status(400).json({ error: 'No files received' });

  const results = [];
  let totalSaved = 0;

  for (const file of req.files) {
    const { finalName, savedBytes } = await processFile(file.path, file.originalname);
    results.push({ name: finalName, saved: savedBytes });
    totalSaved += savedBytes;
  }

  const dir = getTodayDir();
  console.log(`\n[+] ${results.length} file(s) received -> ${dir}`);
  results.forEach(r => {
    const saving = r.saved > 0 ? ` (saved ${formatSize(r.saved)})` : '';
    console.log(`    -> ${r.name}${saving}`);
  });
  if (totalSaved > 0) console.log(`    [~] Total saved: ${formatSize(totalSaved)}`);

  res.json({ ok: true, files: results.map(r => r.name), savedBytes: totalSaved });
});

// Files JSON API
app.get('/files', (_req, res) => {
  const results = [];
  try {
    const days = fs.readdirSync(RECEIVED_DIR)
      .filter(d => fs.statSync(path.join(RECEIVED_DIR, d)).isDirectory())
      .sort().reverse();
    for (const day of days) {
      const dayDir = path.join(RECEIVED_DIR, day);
      const files  = fs.readdirSync(dayDir).map(name => {
        const stat = fs.statSync(path.join(dayDir, name));
        return { name, date: day, size: stat.size, time: stat.mtimeMs, isImage: isImage(name), url: `/received/${day}/${name}` };
      }).sort((a, b) => b.time - a.time);
      results.push(...files);
    }
  } catch (e) {}
  res.json(results);
});

// Gallery page
app.get('/gallery', (_req, res) => res.send(GALLERY_HTML));

// Main upload page
app.get('/', async (req, res) => {
  const port    = req.socket.localPort;
  const rawAddr = (req.socket.localAddress || '').replace('::ffff:', '');
  const isLocal = rawAddr === '127.0.0.1' || rawAddr === '::1' || rawAddr === '';
  let host;
  if (isLocal) {
    const ips     = getAllLocalIPs();
    const hotspot = ips.find(i => i.ip.startsWith('192.168.137.'));
    host = hotspot ? hotspot.ip : (ips[0] ? ips[0].ip : '127.0.0.1');
  } else {
    host = rawAddr;
  }
  const baseUrl = `http://${host}:${port}`;
  const qr = await QRCode.toDataURL(baseUrl, { width: 220, margin: 1, color: { dark: '#ffffff', light: '#00000000' } });
  res.send(getMainHTML(baseUrl, qr));
});

// ─── HTML: Main page ───────────────────────────────────────────────────────
function getMainHTML(baseUrl, qrDataUrl) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>PhoneDrop</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :root{--bg:#0d0d0d;--surface:#161616;--border:#2a2a2a;--accent:#e8ff47;--accent2:#47c8ff;--text:#f0f0f0;--muted:#666;--success:#4dff91;--error:#ff4d6d;--mono:'IBM Plex Mono',monospace;--sans:'IBM Plex Sans',sans-serif}
  body{background:var(--bg);color:var(--text);font-family:var(--sans);min-height:100vh;display:flex;flex-direction:column}
  header{padding:20px 28px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px}
  .logo{font-family:var(--mono);font-weight:600;font-size:1.1rem;color:var(--accent);letter-spacing:-0.02em}
  .logo span{color:var(--muted)}
  .status-dot{width:7px;height:7px;border-radius:50%;background:var(--success);box-shadow:0 0 8px var(--success);animation:pulse 2s infinite;margin-left:auto}
  .status-text{font-family:var(--mono);font-size:0.7rem;color:var(--success)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
  main{flex:1;display:grid;grid-template-columns:1fr 1fr}
  @media(max-width:700px){main{grid-template-columns:1fr}.qr-panel{border-right:none;border-bottom:1px solid var(--border)}}
  .panel{padding:32px 28px}
  .qr-panel{border-right:1px solid var(--border);display:flex;flex-direction:column;gap:20px}
  .panel-label{font-family:var(--mono);font-size:0.65rem;color:var(--muted);letter-spacing:0.12em;text-transform:uppercase}
  .qr-box{background:#1a1a1a;border:1px solid var(--border);border-radius:12px;padding:20px;display:flex;flex-direction:column;align-items:center;gap:16px}
  .qr-box img{width:180px;height:180px}
  .qr-url{font-family:var(--mono);font-size:0.75rem;color:var(--accent2);background:#0d1a24;padding:8px 14px;border-radius:6px;border:1px solid #1a3a50;width:100%;text-align:center;word-break:break-all}
  .hint{font-size:0.8rem;color:var(--muted);line-height:1.9}
  .hint strong{color:var(--text)}
  .upload-panel{display:flex;flex-direction:column;gap:20px}
  .drop-zone{border:2px dashed var(--border);border-radius:12px;padding:40px 20px;text-align:center;cursor:pointer;transition:border-color 0.2s,background 0.2s;position:relative}
  .drop-zone:hover,.drop-zone.dragging{border-color:var(--accent);background:#1a1a00}
  .drop-zone input{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}
  .drop-icon{font-size:2.5rem;margin-bottom:12px;display:block}
  .drop-title{font-weight:600;font-size:1rem;margin-bottom:6px}
  .drop-sub{font-size:0.78rem;color:var(--muted)}
  .file-list{display:flex;flex-direction:column;gap:8px}
  .file-item{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:10px;font-size:0.82rem;animation:slideIn 0.2s ease}
  @keyframes slideIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
  .file-name{flex:1;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .file-size{color:var(--muted);font-family:var(--mono);font-size:0.7rem;white-space:nowrap}
  .remove-btn{background:none;border:none;color:var(--muted);cursor:pointer;font-size:1.1rem;padding:0 2px;line-height:1}
  .btn{padding:12px 24px;border-radius:8px;border:none;font-family:var(--mono);font-size:0.85rem;font-weight:600;cursor:pointer;transition:all 0.15s;letter-spacing:.03em}
  .btn-primary{background:var(--accent);color:#000;width:100%}
  .btn-primary:hover{background:#d4e83e;transform:translateY(-1px)}
  .btn-primary:active{transform:translateY(0)}
  .btn-primary:disabled{opacity:0.4;cursor:not-allowed;transform:none}
  .btn-secondary{background:var(--surface);color:var(--accent2);border:1px solid var(--border);width:100%;text-decoration:none;display:block;text-align:center;padding:12px 24px;border-radius:8px;font-family:var(--mono);font-size:0.85rem;font-weight:600}
  .btn-secondary:hover{border-color:var(--accent2);background:#0d1a24}
  .toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(80px);background:var(--success);color:#000;font-family:var(--mono);font-size:0.8rem;padding:10px 20px;border-radius:30px;font-weight:600;transition:transform 0.3s ease;z-index:99}
  .toast.show{transform:translateX(-50%) translateY(0)}
  .toast.error{background:var(--error);color:#fff}
  .received-section{border-top:1px solid var(--border);padding:24px 28px}
  .received-header{display:flex;align-items:center;gap:12px;margin-bottom:16px}
  .received-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}
  .received-item{background:var(--surface);border:1px solid var(--border);border-radius:8px;overflow:hidden;animation:slideIn 0.2s ease;display:flex;flex-direction:column}
  .received-thumb{width:100%;aspect-ratio:1;object-fit:cover;background:#1a1a1a;display:block}
  .received-thumb-placeholder{width:100%;aspect-ratio:1;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:2rem}
  .received-info{padding:8px 10px}
  .received-name{font-family:var(--mono);font-size:0.7rem;color:var(--accent2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px}
  .received-meta{color:var(--muted);font-size:0.68rem;display:flex;justify-content:space-between;align-items:center}
  .dl-link{color:var(--accent);font-size:0.65rem;text-decoration:none;font-family:var(--mono)}
  .dl-link:hover{text-decoration:underline}
  .empty-state{color:var(--muted);font-size:0.8rem;font-family:var(--mono);padding:8px 0}
  .badge{background:var(--accent);color:#000;font-family:var(--mono);font-size:0.65rem;font-weight:600;padding:2px 8px;border-radius:20px}
  .gallery-link{margin-left:auto;font-family:var(--mono);font-size:0.7rem;color:var(--accent2);text-decoration:none;border:1px solid var(--border);padding:3px 10px;border-radius:20px}
  .gallery-link:hover{border-color:var(--accent2)}
  .saved-tag{font-family:var(--mono);font-size:0.6rem;color:var(--success);background:#001a08;border:1px solid #004d1a;padding:1px 6px;border-radius:10px;white-space:nowrap}
  .quality-row{display:flex;align-items:center;gap:10px;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:10px 14px}
  .quality-label{font-family:var(--mono);font-size:0.72rem;color:var(--muted);white-space:nowrap}
  .quality-slider{flex:1;accent-color:var(--accent);height:4px;cursor:pointer}
  .quality-val{font-family:var(--mono);font-size:0.8rem;color:var(--accent);font-weight:600;min-width:36px;text-align:right}
  .quality-hint{font-family:var(--mono);font-size:0.6rem;color:var(--muted);margin-top:2px}
  .received-item{cursor:pointer}
  .received-item:hover{border-color:var(--accent2);transform:translateY(-1px);transition:border-color 0.15s,transform 0.15s}
  .lb{position:fixed;inset:0;background:rgba(0,0,0,0.92);z-index:100;display:none;flex-direction:column;align-items:center;justify-content:center;padding:16px}
  .lb.open{display:flex}
  .lb-img{max-width:100%;max-height:80vh;object-fit:contain;border-radius:8px}
  .lb-bar{display:flex;align-items:center;gap:16px;padding:16px 0 4px;width:100%;max-width:600px}
  .lb-name{font-family:var(--mono);font-size:0.75rem;color:var(--text);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .lb-size{font-family:var(--mono);font-size:0.7rem;color:var(--muted)}
  .lb-dl{background:var(--accent);color:#000;font-family:var(--mono);font-size:0.75rem;font-weight:600;padding:8px 18px;border-radius:6px;text-decoration:none}
  .lb-dl:hover{background:#d4e83e}
  .lb-close{background:none;border:1px solid var(--border);color:var(--muted);font-family:var(--mono);font-size:0.75rem;padding:8px 14px;border-radius:6px;cursor:pointer;margin-left:auto}
  .lb-close:hover{color:var(--text);border-color:var(--text)}
  .lb-nav{display:flex;gap:10px;margin-top:12px}
  .lb-nav button{background:var(--surface);border:1px solid var(--border);color:var(--text);font-family:var(--mono);font-size:0.8rem;padding:8px 20px;border-radius:6px;cursor:pointer}
  .lb-nav button:hover{border-color:var(--accent2)}
  .lb-nav button:disabled{opacity:0.3;cursor:default}
</style>
</head>
<body>
<header>
  <div class="logo">phone<span>//</span>drop</div>
  <div class="status-text">LIVE</div>
  <div class="status-dot"></div>
</header>
<main>
  <div class="panel qr-panel">
    <div class="panel-label">Scan to open on phone</div>
    <div class="qr-box">
      <img src="${qrDataUrl}" alt="QR Code"/>
      <div class="qr-url">${baseUrl}</div>
    </div>
    <p class="hint">
      <strong>1.</strong> Open your iPhone camera<br/>
      <strong>2.</strong> Scan the QR code above<br/>
      <strong>3.</strong> Take photos or pick from gallery<br/>
      <strong>4.</strong> Tap again to add more, then Send
    </p>
  </div>
  <div class="panel upload-panel">
    <div class="panel-label">Upload files</div>
    <div class="drop-zone" id="dropZone">
      <input type="file" id="fileInput" multiple accept="image/*,video/*,.pdf,.doc,.docx"/>
      <span class="drop-icon">&#128247;</span>
      <div class="drop-title">Tap to add photos</div>
      <div class="drop-sub">Tap again to add more — they stack up</div>
    </div>
    <div class="file-list" id="fileList"></div>
    <button class="btn btn-primary" id="uploadBtn" disabled>Send to PC</button>
    <a class="btn btn-secondary" href="/gallery">&#128444; Browse received files</a>
    <div class="quality-row">
      <span class="quality-label">Compression</span>
      <input class="quality-slider" type="range" id="qualitySlider" min="1" max="100" value="92"/>
      <span class="quality-val" id="qualityVal">92%</span>
    </div>
    <div class="quality-hint" id="qualityHint">Visually lossless &mdash; PNG is always lossless</div>
  </div>
</main>
<div class="received-section">
  <div class="received-header">
    <div class="panel-label">Recently received</div>
    <span class="badge" id="fileCount">0</span>
    <a class="gallery-link" href="/gallery">View all &rarr;</a>
  </div>
  <div class="received-grid" id="receivedGrid"><div class="empty-state">No files yet...</div></div>
</div>
<div class="lb" id="lb">
  <div class="lb-bar">
    <span class="lb-name" id="lbName"></span>
    <span class="lb-size" id="lbSize"></span>
    <a class="lb-dl" id="lbDl" download>&#8675; Save</a>
    <button class="lb-close" onclick="closeLb()">close</button>
  </div>
  <img class="lb-img" id="lbImg" src="" alt=""/>
  <div class="lb-nav">
    <button id="lbPrev" onclick="navLb(-1)">&#8592; prev</button>
    <button id="lbNext" onclick="navLb(1)">next &#8594;</button>
  </div>
</div>
<div class="toast" id="toast"></div>
<script>
  var fileInput=document.getElementById('fileInput');
  var dropZone=document.getElementById('dropZone');
  var fileList=document.getElementById('fileList');
  var uploadBtn=document.getElementById('uploadBtn');
  var toast=document.getElementById('toast');
  var receivedGrid=document.getElementById('receivedGrid');
  var fileCount=document.getElementById('fileCount');
  var qualitySlider=document.getElementById('qualitySlider');
  var qualityVal=document.getElementById('qualityVal');
  var qualityHint=document.getElementById('qualityHint');
  var selectedFiles=[];
  var recentFiles=[];
  var lbImgs=[],lbIndex=0;

  // ── Quality slider ──────────────────────────────────────────────────────
  var qualityHints={
    90:'Visually lossless \u2014 PNG is always lossless',
    75:'Great quality, noticeable savings',
    50:'Smaller files, slight visible loss',
    0:'Heavy compression, visible quality loss'
  };
  function getHint(q){
    if(q>=90)return qualityHints[90];
    if(q>=75)return qualityHints[75];
    if(q>=50)return qualityHints[50];
    return qualityHints[0];
  }

  // Load current quality from server on startup
  fetch('/config').then(function(r){return r.json();}).then(function(d){
    qualitySlider.value=d.quality;
    qualityVal.textContent=d.quality+'%';
    qualityHint.textContent=getHint(d.quality);
  }).catch(function(){});

  var qualityTimer=null;
  qualitySlider.addEventListener('input',function(){
    var q=parseInt(qualitySlider.value,10);
    qualityVal.textContent=q+'%';
    qualityHint.textContent=getHint(q);
    clearTimeout(qualityTimer);
    qualityTimer=setTimeout(function(){
      fetch('/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({quality:q})})
        .catch(function(){});
    },400);
  });

  // ── File list ───────────────────────────────────────────────────────────
  function formatSize(b){
    if(b<1024)return b+' B';
    if(b<1048576)return(b/1024).toFixed(1)+' KB';
    return(b/1048576).toFixed(1)+' MB';
  }

  function showToast(msg,isError){
    toast.textContent=msg;
    toast.className='toast'+(isError?' error':'');
    toast.classList.add('show');
    setTimeout(function(){toast.classList.remove('show');},3500);
  }

  function removeFile(i){selectedFiles.splice(i,1);renderFileList();}

  function renderFileList(){
    fileList.innerHTML='';
    selectedFiles.forEach(function(f,i){
      var d=document.createElement('div');
      d.className='file-item';
      d.innerHTML='<span id="st'+i+'">&#9203;</span>'
        +'<span class="file-name">'+f.name+'</span>'
        +'<span class="file-size">'+formatSize(f.size)+'</span>'
        +'<button class="remove-btn" onclick="removeFile('+i+')" title="Remove">&times;</button>';
      fileList.appendChild(d);
    });
    uploadBtn.disabled=selectedFiles.length===0;
    uploadBtn.textContent=selectedFiles.length===0?'Send to PC':'Send to PC ('+selectedFiles.length+')';
  }

  fileInput.addEventListener('change',function(){
    Array.from(fileInput.files).forEach(function(f){
      if(!selectedFiles.some(function(e){return e.name===f.name&&e.size===f.size;}))selectedFiles.push(f);
    });
    fileInput.value='';renderFileList();
  });

  dropZone.addEventListener('dragover',function(e){e.preventDefault();dropZone.classList.add('dragging');});
  dropZone.addEventListener('dragleave',function(){dropZone.classList.remove('dragging');});
  dropZone.addEventListener('drop',function(e){
    e.preventDefault();dropZone.classList.remove('dragging');
    Array.from(e.dataTransfer.files).forEach(function(f){
      if(!selectedFiles.some(function(e){return e.name===f.name&&e.size===f.size;}))selectedFiles.push(f);
    });
    renderFileList();
  });

  uploadBtn.addEventListener('click',function(){
    if(!selectedFiles.length)return;
    uploadBtn.disabled=true;uploadBtn.textContent='Sending...';
    var fd=new FormData();
    selectedFiles.forEach(function(f){fd.append('files',f);});
    fetch('/upload',{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(data){
        if(data.ok){
          selectedFiles.forEach(function(_,i){var s=document.getElementById('st'+i);if(s)s.textContent='&#9989;';});
          var msg=data.files.length+' file(s) saved!';
          if(data.savedBytes>0)msg+=' ('+formatSize(data.savedBytes)+' smaller)';
          showToast(msg);
          selectedFiles=[];fileInput.value='';
          uploadBtn.textContent='Send to PC';uploadBtn.disabled=true;
          loadReceived();
        } else {throw new Error('failed');}
      })
      .catch(function(){
        showToast('Upload failed. Same network?',true);
        uploadBtn.textContent='Send to PC ('+selectedFiles.length+')';
        uploadBtn.disabled=false;
      });
  });

  // ── Recently received + lightbox ────────────────────────────────────────
  function openLb(idx){
    lbIndex=idx;
    updateLb();
    document.getElementById('lb').classList.add('open');
  }

  function updateLb(){
    var f=lbImgs[lbIndex];
    document.getElementById('lbImg').src=f.url;
    document.getElementById('lbName').textContent=f.name;
    document.getElementById('lbSize').textContent=formatSize(f.size);
    document.getElementById('lbDl').href=f.url;
    document.getElementById('lbDl').download=f.name;
    document.getElementById('lbPrev').disabled=lbIndex===0;
    document.getElementById('lbNext').disabled=lbIndex===lbImgs.length-1;
  }

  function navLb(dir){lbIndex=Math.max(0,Math.min(lbImgs.length-1,lbIndex+dir));updateLb();}
  function closeLb(){document.getElementById('lb').classList.remove('open');}

  document.addEventListener('keydown',function(e){
    if(!document.getElementById('lb').classList.contains('open'))return;
    if(e.key==='Escape')closeLb();
    if(e.key==='ArrowLeft')navLb(-1);
    if(e.key==='ArrowRight')navLb(1);
  });
  document.getElementById('lb').addEventListener('click',function(e){if(e.target===this)closeLb();});

  function loadReceived(){
    fetch('/files')
      .then(function(r){return r.json();})
      .then(function(files){
        fileCount.textContent=files.length;
        var recent=files.slice(0,12);
        recentFiles=recent;
        lbImgs=recent.filter(function(f){return f.isImage;});
        if(!recent.length){receivedGrid.innerHTML='<div class="empty-state">No files yet...</div>';return;}
        receivedGrid.innerHTML=recent.map(function(f){
          var imgIdx=lbImgs.indexOf(f);
          var clickable=f.isImage?' onclick="openLb('+imgIdx+')"':'';
          var thumb=f.isImage
            ?'<img class="received-thumb" src="'+f.url+'" loading="lazy" alt="'+f.name+'">'
            :'<div class="received-thumb-placeholder">&#128196;</div>';
          return '<div class="received-item"'+clickable+'>'+thumb
            +'<div class="received-info">'
            +'<div class="received-name">'+f.name+'</div>'
            +'<div class="received-meta"><span>'+formatSize(f.size)+'</span>'
            +'<a class="dl-link" href="'+f.url+'" download="'+f.name+'" onclick="event.stopPropagation()">&#8675; save</a>'
            +'</div></div></div>';
        }).join('');
      }).catch(function(){});
  }

  loadReceived();
  setInterval(loadReceived,3000);
</script>
</body>
</html>`;
}

// ─── HTML: Gallery page ────────────────────────────────────────────────────
const GALLERY_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>PhoneDrop — Gallery</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :root{--bg:#0d0d0d;--surface:#161616;--border:#2a2a2a;--accent:#e8ff47;--accent2:#47c8ff;--text:#f0f0f0;--muted:#666;--success:#4dff91;--error:#ff4d6d;--mono:'IBM Plex Mono',monospace;--sans:'IBM Plex Sans',sans-serif}
  body{background:var(--bg);color:var(--text);font-family:var(--sans);min-height:100vh;display:flex;flex-direction:column}
  header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;position:sticky;top:0;background:var(--bg);z-index:10}
  .logo{font-family:var(--mono);font-weight:600;font-size:1rem;color:var(--accent)}
  .logo span{color:var(--muted)}
  .back{font-family:var(--mono);font-size:0.75rem;color:var(--muted);text-decoration:none;margin-right:4px}
  .back:hover{color:var(--text)}
  .page-title{font-family:var(--mono);font-size:0.75rem;color:var(--muted);margin-left:auto}
  .controls{padding:16px 20px;display:flex;gap:10px;align-items:center;border-bottom:1px solid var(--border);flex-wrap:wrap}
  .search{background:var(--surface);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:var(--mono);font-size:0.8rem;padding:8px 14px;flex:1;min-width:160px;outline:none}
  .search:focus{border-color:var(--accent2)}
  .filter-btn{background:var(--surface);border:1px solid var(--border);border-radius:8px;color:var(--muted);font-family:var(--mono);font-size:0.75rem;padding:8px 14px;cursor:pointer}
  .filter-btn.active{border-color:var(--accent);color:var(--accent)}
  .count{font-family:var(--mono);font-size:0.7rem;color:var(--muted);margin-left:auto}
  .day-group{padding:16px 20px 0}
  .day-label{font-family:var(--mono);font-size:0.65rem;color:var(--muted);letter-spacing:0.1em;text-transform:uppercase;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border)}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;margin-bottom:8px}
  @media(min-width:600px){.grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}}
  .card{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden;cursor:pointer;transition:border-color 0.15s,transform 0.15s}
  .card:hover{border-color:var(--accent2);transform:translateY(-2px)}
  .card img{width:100%;aspect-ratio:1;object-fit:cover;display:block;background:#1a1a1a}
  .card-placeholder{width:100%;aspect-ratio:1;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:2.2rem}
  .card-info{padding:8px 10px}
  .card-name{font-family:var(--mono);font-size:0.68rem;color:var(--accent2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:3px}
  .card-meta{font-size:0.65rem;color:var(--muted);display:flex;justify-content:space-between}
  .dl-btn{color:var(--accent);text-decoration:none;font-family:var(--mono);font-size:0.65rem}
  .dl-btn:hover{text-decoration:underline}
  .empty{text-align:center;padding:60px 20px;color:var(--muted);font-family:var(--mono);font-size:0.85rem}
  .lb{position:fixed;inset:0;background:rgba(0,0,0,0.92);z-index:100;display:none;flex-direction:column;align-items:center;justify-content:center;padding:16px}
  .lb.open{display:flex}
  .lb-img{max-width:100%;max-height:80vh;object-fit:contain;border-radius:8px}
  .lb-bar{display:flex;align-items:center;gap:16px;padding:16px 0 4px;width:100%;max-width:600px}
  .lb-name{font-family:var(--mono);font-size:0.75rem;color:var(--text);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .lb-size{font-family:var(--mono);font-size:0.7rem;color:var(--muted)}
  .lb-dl{background:var(--accent);color:#000;font-family:var(--mono);font-size:0.75rem;font-weight:600;padding:8px 18px;border-radius:6px;text-decoration:none}
  .lb-dl:hover{background:#d4e83e}
  .lb-close{background:none;border:1px solid var(--border);color:var(--muted);font-family:var(--mono);font-size:0.75rem;padding:8px 14px;border-radius:6px;cursor:pointer;margin-left:auto}
  .lb-close:hover{color:var(--text);border-color:var(--text)}
  .lb-nav{display:flex;gap:10px;margin-top:12px}
  .lb-nav button{background:var(--surface);border:1px solid var(--border);color:var(--text);font-family:var(--mono);font-size:0.8rem;padding:8px 20px;border-radius:6px;cursor:pointer}
  .lb-nav button:hover{border-color:var(--accent2)}
  .lb-nav button:disabled{opacity:0.3;cursor:default}
</style>
</head>
<body>
<header>
  <a class="back" href="/">&#8592;</a>
  <div class="logo">phone<span>//</span>drop</div>
  <div class="page-title">gallery</div>
</header>
<div class="controls">
  <input class="search" id="search" type="text" placeholder="Search files..." oninput="applyFilter()"/>
  <button class="filter-btn active" id="btnAll" onclick="setFilter('all')">All</button>
  <button class="filter-btn" id="btnImg" onclick="setFilter('images')">Images</button>
  <button class="filter-btn" id="btnOther" onclick="setFilter('other')">Other</button>
  <span class="count" id="countLabel">0 files</span>
</div>
<div id="content"><div class="empty">Loading...</div></div>
<div class="lb" id="lb">
  <div class="lb-bar">
    <span class="lb-name" id="lbName"></span>
    <span class="lb-size" id="lbSize"></span>
    <a class="lb-dl" id="lbDl" download>&#8675; Save</a>
    <button class="lb-close" onclick="closeLb()">close</button>
  </div>
  <img class="lb-img" id="lbImg" src="" alt=""/>
  <div class="lb-nav">
    <button id="lbPrev" onclick="navLb(-1)">&#8592; prev</button>
    <button id="lbNext" onclick="navLb(1)">next &#8594;</button>
  </div>
</div>
<script>
  var allFiles=[],filtered=[],currentFilter='all',lbIndex=0,lbImgs=[];

  function formatSize(b){
    if(b<1024)return b+' B';
    if(b<1048576)return(b/1024).toFixed(1)+' KB';
    return(b/1048576).toFixed(1)+' MB';
  }

  function setFilter(f){
    currentFilter=f;
    ['All','Img','Other'].forEach(function(x){
      document.getElementById('btn'+x).className='filter-btn'+(f==={All:'all',Img:'images',Other:'other'}[x]?' active':'');
    });
    applyFilter();
  }

  function applyFilter(){
    var q=document.getElementById('search').value.toLowerCase();
    filtered=allFiles.filter(function(f){
      if(currentFilter==='images'&&!f.isImage)return false;
      if(currentFilter==='other'&&f.isImage)return false;
      if(q&&f.name.toLowerCase().indexOf(q)===-1)return false;
      return true;
    });
    render();
  }

  function render(){
    document.getElementById('countLabel').textContent=filtered.length+' file'+(filtered.length===1?'':'s');
    if(!filtered.length){document.getElementById('content').innerHTML='<div class="empty">No files found</div>';return;}
    var groups={},order=[];
    filtered.forEach(function(f){if(!groups[f.date]){groups[f.date]=[];order.push(f.date);}groups[f.date].push(f);});
    order=order.filter(function(v,i){return order.indexOf(v)===i;});
    var html='';
    order.forEach(function(day){
      html+='<div class="day-group"><div class="day-label">'+day+'</div><div class="grid">';
      groups[day].forEach(function(f){
        var idx=filtered.indexOf(f);
        if(f.isImage){
          html+='<div class="card" onclick="openLb('+idx+')">'
            +'<img src="'+f.url+'" loading="lazy" alt="'+f.name+'">'
            +'<div class="card-info"><div class="card-name">'+f.name+'</div>'
            +'<div class="card-meta"><span>'+formatSize(f.size)+'</span>'
            +'<a class="dl-btn" href="'+f.url+'" download="'+f.name+'" onclick="event.stopPropagation()">&#8675; save</a>'
            +'</div></div></div>';
        } else {
          html+='<div class="card"><div class="card-placeholder">&#128196;</div>'
            +'<div class="card-info"><div class="card-name">'+f.name+'</div>'
            +'<div class="card-meta"><span>'+formatSize(f.size)+'</span>'
            +'<a class="dl-btn" href="'+f.url+'" download="'+f.name+'">&#8675; save</a>'
            +'</div></div></div>';
        }
      });
      html+='</div></div>';
    });
    document.getElementById('content').innerHTML=html;
  }

  function openLb(idx){
    var f=filtered[idx];
    if(!f||!f.isImage)return;
    lbImgs=filtered.filter(function(x){return x.isImage;});
    lbIndex=lbImgs.indexOf(f);
    updateLb();
    document.getElementById('lb').classList.add('open');
  }

  function updateLb(){
    var f=lbImgs[lbIndex];
    document.getElementById('lbImg').src=f.url;
    document.getElementById('lbName').textContent=f.name;
    document.getElementById('lbSize').textContent=formatSize(f.size);
    document.getElementById('lbDl').href=f.url;
    document.getElementById('lbDl').download=f.name;
    document.getElementById('lbPrev').disabled=lbIndex===0;
    document.getElementById('lbNext').disabled=lbIndex===lbImgs.length-1;
  }

  function navLb(dir){lbIndex=Math.max(0,Math.min(lbImgs.length-1,lbIndex+dir));updateLb();}
  function closeLb(){document.getElementById('lb').classList.remove('open');}

  document.addEventListener('keydown',function(e){
    if(!document.getElementById('lb').classList.contains('open'))return;
    if(e.key==='Escape')closeLb();
    if(e.key==='ArrowLeft')navLb(-1);
    if(e.key==='ArrowRight')navLb(1);
  });
  document.getElementById('lb').addEventListener('click',function(e){if(e.target===this)closeLb();});

  function load(){
    fetch('/files').then(function(r){return r.json();}).then(function(files){allFiles=files;applyFilter();})
      .catch(function(){document.getElementById('content').innerHTML='<div class="empty">Could not load files</div>';});
  }
  load();setInterval(load,5000);
</script>
</body>
</html>`;

// ─── Start ─────────────────────────────────────────────────────────────────
async function start() {
  const ips        = getAllLocalIPs();
  const tailscaleIP = getTailscaleIP();

  if (ips.length === 0 && !tailscaleIP) {
    console.error('[!] No network detected. Connect to WiFi, Ethernet, Tailscale, or start your mobile hotspot.');
    process.exit(1);
  }

  const port = await findFreePort(BASE_PORT);
  if (!port) {
    console.error(`[!] Could not find a free port in range ${BASE_PORT}-${BASE_PORT + 19}`);
    process.exit(1);
  }

  if (port !== BASE_PORT) console.log(`[~] Port ${BASE_PORT} in use, using ${port} instead.`);

  app.listen(port, '0.0.0.0', () => {
    console.log('');
    console.log('+--------------------------------------------+');
    console.log('|        PhoneDrop  [phone -> PC]            |');
    console.log('+--------------------------------------------+');
    console.log('| Open in your browser:                      |');
    console.log(`|   http://localhost:${port}                   |`);
    console.log('+--------------------------------------------+');

    if (tailscaleIP) {
      console.log('| Tailscale (works anywhere):                |');
      console.log(`|   http://${tailscaleIP}:${port}           |`);
      console.log('+--------------------------------------------+');
    }

    if (ips.length > 0) {
      console.log('| Local WiFi (same network only):            |');
      ips.forEach(({ ip }) => console.log(`|   http://${ip}:${port}`));
      console.log('+--------------------------------------------+');
    }

    console.log(`| Gallery:  http://localhost:${port}/gallery     |`);
    console.log('+--------------------------------------------+');
    console.log('| Files saved to: ./received/YYYY-MM-DD/     |');
    console.log('| Images auto-optimized (metadata stripped)  |');
    console.log('| Press Ctrl+C to stop                       |');
    console.log('+--------------------------------------------+');
    console.log('');
  });
}

start();
