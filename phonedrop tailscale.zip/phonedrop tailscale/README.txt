PhoneDrop - Send photos from iPhone to PC instantly
====================================================

REQUIREMENTS
  - Node.js installed (https://nodejs.org)
    If not installed, PhoneDrop.bat will try to install it automatically via winget.

HOW TO USE
  1. Double-click PhoneDrop.bat
  2. Your browser opens automatically
  3. Scan the QR code with your iPhone (must be on same WiFi or hotspot)
  4. Take a photo or pick from gallery -> tap Send to PC
  5. File appears instantly in the "received" folder

GALLERY
  - Click "Browse received files" in the app, or go to:
    http://<your-ip>:<port>/gallery
  - Browse, search, filter, preview and download files from any device on the network

IMAGE OPTIMIZATION
  - JPEG, PNG and WebP files are automatically optimized on upload
  - Same format and visual quality — only metadata (EXIF, GPS) is stripped
    and compression is improved
  - Typically saves 20–50% file size on iPhone photos
  - How much was saved is shown in the upload confirmation toast
  - Non-image files (video, PDF, etc.) are saved as-is

NOTES
  - Both devices must be on the same network (WiFi, hotspot, or LAN)
  - Files are saved in the "received" folder next to PhoneDrop.bat
  - Close the terminal window to stop the server
  - Max file size: 50MB per file

ACCESSING FROM OTHER COMPUTERS
  - Open a browser on any PC on the same network
  - Go to http://<ip shown in terminal>:<port>
  - Gallery works the same way from any browser

WANT A REAL .EXE?
  Install Node.js, then run this once in the folder:
    npm install -g pkg
    pkg index.js --target node18-win-x64 --output PhoneDrop.exe
  This compiles a standalone exe (note: sharp binaries may need bundling separately).
